KindEditor ASP.NET

本ASP.NET程序是演示程序，建议不要直接在实际项目中使用。
如果您确定直接使用本程序，使用之前请仔细确认相关安全设置。
 
使用方法:

1. 解压zip文件，将所有文件复制到IIS的wwwroot/kindeditor目录下。

2. 将kindeditor/asp.net/bin目录下的dll文件复制到wwwroot/bin目录下。

3. 打开浏览器，输入http://localhost:[P0RT]/kindeditor/asp.net/demo.aspx。
